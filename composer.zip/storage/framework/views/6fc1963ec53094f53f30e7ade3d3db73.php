<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'پروژه'); ?></title>
    <!-- می‌توانید استایل‌ها و اسکریپت‌های خود را اینجا اضافه کنید -->
</head>
<body>

    <header>
        <!-- هدر سایت -->
    </header>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer>
        <!-- فوتر سایت -->
    </footer>

</body>
</html>
<?php /**PATH C:\Users\Alix\Desktop\project\monitoring\resources\views/layouts/app.blade.php ENDPATH**/ ?>