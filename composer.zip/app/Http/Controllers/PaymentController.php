<?php

namespace App\Http\Controllers;

use App\Models\Payment;
use App\Models\Order;
use Illuminate\Http\Request;
use Shetabit\Payment\Facade\Payment as PaymentGateway;
use Shetabit\Multipay\Exceptions\InvalidTransactionException;
    use Illuminate\Support\Facades\Log;

class PaymentController extends Controller
{
    // صفحه پرداخت
    // public function pay(Request $request)
    // {
    //     // فرض می‌کنیم که مبلغ و اطلاعات پرداخت از فرانت‌اند می‌آید
    //     $order = Order::findOrFail($request->input('order_id'));
    //     $amount = $order->total_amount; // مبلغ کل سفارش

    //     $invoice = (new \Shetabit\Multipay\Invoice)->amount($amount);

    //     // خرید از درگاه
    //     return PaymentGateway::via('zarinpal')->purchase($invoice, function($driver, $transactionId) use ($order) {
    //         // ذخیره اطلاعات پرداخت در جدول payments
    //         Payment::create([
    //             'order_id' => $order->id,
    //             'user_id' => $order->user_id,
    //             'transaction_id' => $transactionId,
    //             'amount' => $order->total_amount,
    //             'currency' => 'R',
    //             'status' => 'pending',
    //         ]);
    //     })->pay()->render();
    // }
    

public function pay(Request $request)
{
    // فرض می‌کنیم که یک سفارش فرضی داریم
    // برای تست یک سفارش با ID 1 را انتخاب می‌کنیم (البته باید این ID در پایگاه داده شما موجود باشد)
    $order = Order::find(1); // فرض می‌کنیم که سفارش با ID 1 داریم

    // بررسی اینکه آیا سفارش موجود است یا نه
    if (!$order) {
        return redirect()->route('home')->withErrors(['error' => 'سفارشی با این شناسه پیدا نشد.']);
    }

    $amount = 1000; // مبلغ پرداخت به تومان
    $amountInRial = $amount * 10; // تبدیل به ریال (1000 تومان = 10000 ریال)

    // لاگ کردن اطلاعات قبل از ارسال به درگاه پرداخت
    Log::debug('Order Information:', ['order' => $order, 'amount' => $amount, 'amountInRial' => $amountInRial]);

    // ایجاد فاکتور (Invoice) برای پرداخت
    $invoice = (new \Shetabit\Multipay\Invoice)->amount($amountInRial);
dd(1);
    // درخواست پرداخت از درگاه زرین‌پال
    try {
        $payment = PaymentGateway::via('zarinpal')->purchase($invoice, function($driver, $transactionId) use ($order) {
            // ذخیره پرداخت در جدول Payment
            Payment::create([
                'order_id' => $order->id,
                'user_id' => auth()->user()->id,
                'transaction_id' => $transactionId,
                'amount' => $order->total_amount, // یا مبلغ دلخواه شما
                'currency' => 'R',
                'status' => 'pending',
            ]);
        });

        // رندر صفحه پرداخت درگاه
        return $payment->pay()->render();
    } catch (\Exception $e) {
        // در صورت بروز خطا در ارتباط با درگاه زرین‌پال
        Log::error('Payment Gateway Error:', ['error' => $e->getMessage()]);
        return redirect()->route('payment.failed')->withErrors(['payment' => 'خطا در پردازش پرداخت']);
    }
}


    // کال‌بک بعد از پرداخت
    public function callback(Request $request)
    {
        
        try {
            // تأیید تراکنش از درگاه زرین‌پال
            $receipt = PaymentGateway::via('zarinpal')->verify();

            // جستجوی پرداخت ثبت شده بر اساس transaction_id
            $payment = Payment::where('transaction_id', $receipt->getTransactionId())->first();

            if ($payment) {
                // تغییر وضعیت پرداخت به موفق
                $payment->status = 'paid';
                $payment->save();

                // ادامه پردازش موفقیت‌آمیز
                return redirect()->route('payment.success')->with('payment', $payment);
            }

            return redirect()->route('payment.failed')->withErrors(['payment' => 'تراکنش یافت نشد']);
        } catch (InvalidTransactionException $e) {
            // تراکنش ناموفق
            Payment::create([
                'transaction_id' => $request->input('transaction_id'),
                'amount' => $request->input('amount'),
                'status' => 'failed',
                'raw_response' => ['error' => $e->getMessage()],
            ]);

            return redirect()->route('payment.failed')->withErrors(['payment' => 'پرداخت ناموفق بود']);
        }
    }

    // صفحه موفقیت
    public function success()
    {
        return view('payment.success');
    }

    // صفحه ناموفق
    public function failed()
    {
        return view('payment.failed');
    }
}
