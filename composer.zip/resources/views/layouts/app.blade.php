<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'پروژه')</title>
    <!-- می‌توانید استایل‌ها و اسکریپت‌های خود را اینجا اضافه کنید -->
</head>
<body>

    <header>
        <!-- هدر سایت -->
    </header>

    <main>
        @yield('content')
    </main>

    <footer>
        <!-- فوتر سایت -->
    </footer>

</body>
</html>
