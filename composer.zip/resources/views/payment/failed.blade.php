@extends('layouts.app')

@section('content')
    <h1>پرداخت ناموفق</h1>
    <pپرداخت شما با مشکل مواجه شد. لطفاً دوباره تلاش کنید.</p>
@endsection
