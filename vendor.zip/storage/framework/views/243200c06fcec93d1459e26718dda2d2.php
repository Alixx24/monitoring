<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <a class="btn btn-success ms-5" type="submit" data-bs-toggle="modal" data-bs-target="#createReqModal">create request</a>
    <a class="btn btn-warning ms-5" type="submit" href="<?php echo e(route('payment.pay')); ?>">+ unlimited (90,000 IRT)</a>

    <section class="hero-section m-md-5 m-3">
<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

        <div class="bg-light mb-3 p-2">
            <h5>
             <?php echo e($user->email); ?>

               
            </h5>
        </div>

        <div class="table-responsive">
            <table class="table">
                <thead class="thead-light">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Duration</th>
                        <th scope="col">Url</th>
                        <th scope="col">Status</th>
                        <th scope="col">Analysis</th>

                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $fetchRequest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row">1</th>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->duration_id); ?> Min</td>
                            <td><?php echo e($item->url); ?></td>
                            <td>
                              
                                <input class="form-check-input status-toggle" type="checkbox" data-id="<?php echo e($item->id); ?>"
                                    <?php echo e($item->status == 1 ? 'checked' : ''); ?>>
                            </td>

                            <td class="d-flex align-items-center">
                                <a class="btn btn-warning"
                                    href="<?php echo e(route('dashboard.analysis.link.index', ['linkId' => auth()->user()->id, 'id' => $item->id])); ?>">Click!</a>

                                <form method="POST"
                                    action="<?php echo e(route('dashboard.request.delete', ['linkId' => $item->id, 'id' => auth()->user()->id])); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger ms-2">Delete</button>
                                </form>
                            </td>


                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

    </section>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
      $(document).ready(function() {
        $('.status-toggle').on('change', function() {
            var itemId = $(this).data('id');
            var status = $(this).is(':checked') ? 1 : 0;

            $.ajax({
                url: '/user/dashboard/update-status/' + itemId,
                method: 'POST',
                data: {
                    status: status,
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    alert('وضعیت با موفقیت بروزرسانی شد');
                },
                error: function () {
                    alert('خطا در بروزرسانی');
                }
            });
        });
    });
    </script>
    <?php if (isset($component)) { $__componentOriginal3fb9cad08083128cd78ae5774a5cc5ed = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fb9cad08083128cd78ae5774a5cc5ed = $attributes; } ?>
<?php $component = App\View\Components\CreateRequestModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('create-request-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\CreateRequestModal::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fb9cad08083128cd78ae5774a5cc5ed)): ?>
<?php $attributes = $__attributesOriginal3fb9cad08083128cd78ae5774a5cc5ed; ?>
<?php unset($__attributesOriginal3fb9cad08083128cd78ae5774a5cc5ed); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fb9cad08083128cd78ae5774a5cc5ed)): ?>
<?php $component = $__componentOriginal3fb9cad08083128cd78ae5774a5cc5ed; ?>
<?php unset($__componentOriginal3fb9cad08083128cd78ae5774a5cc5ed); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Alix\Desktop\project\monitoring\resources\views/customer/dashboard/index.blade.php ENDPATH**/ ?>