    <section>
      <!-- Footer -->
      <footer class="text-center">
        <!-- Grid container -->
    
        <div >
         
          <a class="text-body text-decoration-none" href="https://mdbootstrap.com/" >© 2025 Designed and Developed by Ali Mohammadi</a>
        </div>
      </footer>
      <!-- Footer -->
    </section><?php /**PATH C:\Users\Alix\Desktop\project\monitoring\resources\views/customer/layouts/footer.blade.php ENDPATH**/ ?>