

<?php $__env->startSection('content'); ?>
    <h1>پرداخت ناموفق</h1>
    <pپرداخت شما با مشکل مواجه شد. لطفاً دوباره تلاش کنید.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Alix\Desktop\project\monitoring\resources\views/payment/failed.blade.php ENDPATH**/ ?>