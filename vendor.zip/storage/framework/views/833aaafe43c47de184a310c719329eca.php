<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('panel.duration.index')); ?>" class="btn btn-primary m-1">Back</a>
    <div class="d-flex justify-content-center align-items-center">

        <form class="col-9" action="<?php echo e(route('panel.duration.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="exampleInputEmail1">Duration</label>
                <input type="number" name="duration" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                    placeholder="Enter Url...">
            </div>






            <button type="submit" class="btn btn-success mt-4">Make it</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Alix\Desktop\project\monitoring\resources\views/panel/duration/create.blade.php ENDPATH**/ ?>