<?php echo $__env->make('panel.layouts.head-tag', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<nav class="navbar navbar-expand-lg navbar-light bg-light mb-5">
    <div class="container-fluid custom-margin-left">
        <a class="navbar-brand" href="<?php echo e(route('home.index')); ?>">Home</a>
        <div class="d-block d-md-none ml-mbobile-sign ">

            <?php if(auth()->guard()->check()): ?>


                <form action="<?php echo e(route('logout.post')); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>

                    <a href="<?php echo e(route('dashboard.index', auth()->user()->id)); ?>" class="btn d-inline  ms-2 ml-mobile"> <i
                            class="bi bi-gear-wide-connected fs-1 text-success p-1"></i>
                    </a>

                </form>
            <?php endif; ?>

            <?php if(auth()->guest()): ?>
                <form class="d-flex">


                    <button type="button" data-bs-toggle="modal" data-bs-target="#loginMobileModal"
                        class="btn border-0 p-0">
                        <i class="fs-1 bi bi-person"></i>
                    </button>

                </form>
            <?php endif; ?>
        </div>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>



        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">


                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">Platform</a>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Viewer
                    </a>

                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="#">Fake views on Telegram</a></li>
                        <li><a class="dropdown-item" href="#">Another action</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item" href="#">Something else here</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Platform
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="#">Action</a></li>
                        <li><a class="dropdown-item" href="#">Another action</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item" href="#">Something else here</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#" tabindex="-1" aria-disabled="true">Enterprise</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('home.document.index')); ?>" tabindex="-1"
                        aria-disabled="true">Documention</a>
                </li>

            </ul>
            <div class="d-none d-md-block">
                <?php if(auth()->guard()->check()): ?>
                    <?php echo e(auth()->user()->email); ?>


                    <form action="<?php echo e(route('logout.post')); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-outline-danger ms-2">
                            Log out
                        </button>
                        <a href="<?php echo e(route('dashboard.index', auth()->user()->id)); ?>"
                            class="btn d-inline btn-outline-success ms-2">Dashboard</a>

                    </form>
                <?php endif; ?>

                <?php if(auth()->guest()): ?>
                    <form class="d-flex">
                        <button type="button" class="btn btn-outline-success me-2" data-bs-toggle="modal"
                            data-bs-target="#loginModal">
                            Login
                        </button>


                        <a class="btn btn-outline-primary me-2" type="submit" data-bs-toggle="modal"
                            data-bs-target="#registerModal">Sign up</a>
                    </form>
                <?php endif; ?>
            </div>

        </div>
    </div>
</nav>



<?php if (isset($component)) { $__componentOriginal60a7ea002b1be577b05b060d6d9f0b0c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal60a7ea002b1be577b05b060d6d9f0b0c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.login-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('login-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal60a7ea002b1be577b05b060d6d9f0b0c)): ?>
<?php $attributes = $__attributesOriginal60a7ea002b1be577b05b060d6d9f0b0c; ?>
<?php unset($__attributesOriginal60a7ea002b1be577b05b060d6d9f0b0c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60a7ea002b1be577b05b060d6d9f0b0c)): ?>
<?php $component = $__componentOriginal60a7ea002b1be577b05b060d6d9f0b0c; ?>
<?php unset($__componentOriginal60a7ea002b1be577b05b060d6d9f0b0c); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal0691ca2f41e893d002008da7cc72d01f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0691ca2f41e893d002008da7cc72d01f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.register-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('register-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0691ca2f41e893d002008da7cc72d01f)): ?>
<?php $attributes = $__attributesOriginal0691ca2f41e893d002008da7cc72d01f; ?>
<?php unset($__attributesOriginal0691ca2f41e893d002008da7cc72d01f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0691ca2f41e893d002008da7cc72d01f)): ?>
<?php $component = $__componentOriginal0691ca2f41e893d002008da7cc72d01f; ?>
<?php unset($__componentOriginal0691ca2f41e893d002008da7cc72d01f); ?>
<?php endif; ?>


<?php if (isset($component)) { $__componentOriginal3893cb610f685f56322b4b4aa842be6b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3893cb610f685f56322b4b4aa842be6b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.register-mobile-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('register-mobile-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3893cb610f685f56322b4b4aa842be6b)): ?>
<?php $attributes = $__attributesOriginal3893cb610f685f56322b4b4aa842be6b; ?>
<?php unset($__attributesOriginal3893cb610f685f56322b4b4aa842be6b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3893cb610f685f56322b4b4aa842be6b)): ?>
<?php $component = $__componentOriginal3893cb610f685f56322b4b4aa842be6b; ?>
<?php unset($__componentOriginal3893cb610f685f56322b4b4aa842be6b); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Alix\Desktop\project\monitoring\resources\views/customer/layouts/header.blade.php ENDPATH**/ ?>