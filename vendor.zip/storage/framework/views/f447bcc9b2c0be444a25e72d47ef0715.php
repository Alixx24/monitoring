<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('panel.duration.create')); ?>" class="btn btn-success">Create</a>
    <table class="table">

        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">duration</th>
                <th scope="col">user_id</th>
            
                <th scope="col">created_at</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $fatchDuration; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row">1</th>
                    <td><?php echo e($request->duration); ?></td>
                    <td><?php echo e($request->user_id); ?></td>
            

  
                    
                    <td><?php echo e($request->created_at); ?></td>

                    <td>
                       

                        <form action="<?php echo e(route('panel.duration.delete', $request->id)); ?>" method="post"
                            style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-danger ">Delete</button>
                        </form>

                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Alix\Desktop\project\monitoring\resources\views/panel/duration/index.blade.php ENDPATH**/ ?>