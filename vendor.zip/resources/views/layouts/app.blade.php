<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'پروژه')</title>
  
</head>
<body>

    <header>

    </header>

    <main>
        @yield('content')
    </main>

    <footer>
     
    </footer>

</body>
</html>
